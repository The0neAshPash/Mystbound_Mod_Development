playsound minecraft:block.moss.hit neutral @a ~ ~ ~
playsound minecraft:block.moss.break neutral @a ~ ~ ~
playsound minecraft:block.moss.place neutral @a ~ ~ ~
particle minecraft:dripping_water ~ ~-0.5 ~ 0.1 0.5 0.1 0 16 force @a