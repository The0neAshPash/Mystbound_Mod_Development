playsound minecraft:block.sand.place neutral @a ~ ~ ~
playsound minecraft:block.wool.place neutral @a ~ ~ ~
particle minecraft:dripping_lava ~ ~ ~ 0.1 0.1 0.1 0.1 16 force @a
particle minecraft:flame ~ ~ ~ 0.3 0.3 0.3 0 4 force @a