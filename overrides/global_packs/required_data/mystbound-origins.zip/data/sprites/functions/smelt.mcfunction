particle minecraft:flame ~ ~ ~ 0.3 0.3 0.3 0.1 64 force @a
playsound minecraft:entity.firework_rocket.large_blast master @a ~ ~ ~
execute positioned ~ ~0.4 ~ rotated ~ ~90 run function sprites:firepulse
execute positioned ~ ~0.4 ~ rotated ~45 ~ run function sprites:firepulse
execute positioned ~ ~0.4 ~ rotated ~-45 ~ run function sprites:firepulse