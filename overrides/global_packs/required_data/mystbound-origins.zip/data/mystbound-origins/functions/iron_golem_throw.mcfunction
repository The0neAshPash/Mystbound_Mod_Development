# Iron Golem Throw Attack
execute as @e[type=!player,distance=..5,sort=nearest,limit=1] at @s run tp @s ^ ^1.5 ^3
execute as @e[type=!player,distance=..5,sort=nearest,limit=1] at @s run data merge entity @s {Motion:[0.0,1.0,1.0]}
execute as @e[type=!player,distance=..5,sort=nearest,limit=1] run damage @s 10
