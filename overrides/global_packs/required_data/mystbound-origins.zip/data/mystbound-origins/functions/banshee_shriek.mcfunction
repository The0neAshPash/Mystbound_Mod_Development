playsound minecraft:entity.warden.sonic_charge player @a ~ ~ ~ 0.68 0.9
playsound minecraft:entity.warden.sonic_boom player @a ~ ~ ~ 1.0 1.0
summon area_effect_cloud ~ ~0.1 ~ {Particle:electric_spark,Potion:wither,Radius:3,Duration:60}
summon area_effect_cloud ~ ~ ~ {Particle:soul,Radius:0.8,RadiusPerTick:0.2,Duration:20}