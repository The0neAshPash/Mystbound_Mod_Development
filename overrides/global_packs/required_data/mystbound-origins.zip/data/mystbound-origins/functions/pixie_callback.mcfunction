scale reset pehkui:base
scale reset pehkui:hitbox_height
scale reset pehkui:hitbox_width
scale reset pehkui:drops
scale reset pehkui:mining_speed
scale reset pehkui:motion
scale delay set 20 @s
scale persist reset pehkui:height @s 
scale persist reset pehkui:width @s
scale persist reset pehkui:hitbox_height @s
scale persist reset pehkui:hitbox_width @s
scale persist reset pehkui:drops @s
scale persist reset pehkui:mining_speed @s
effect clear @s minecraft:levitation