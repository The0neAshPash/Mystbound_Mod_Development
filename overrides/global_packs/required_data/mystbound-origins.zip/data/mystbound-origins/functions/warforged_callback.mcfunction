scale reset pehkui:height
scale reset pehkui:width
scale reset pehkui:motion
scale persist reset pehkui:height @s
scale persist reset pehkui:width @s
scale persist reset pehkui:motion @s
