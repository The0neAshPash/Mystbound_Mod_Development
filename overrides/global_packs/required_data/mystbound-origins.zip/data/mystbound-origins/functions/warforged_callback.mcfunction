scale reset pehkui:base
scale reset pehkui:width
scale reset pehkui:hitbox_width
scale persist reset pehkui:base @s
scale persist reset pehkui:width @s
scale persist reset pehkui:motion @s
