scale set pehkui:base 0.75
scale set pehkui:motion 1.8
scale set pehkui:attack 1
scale set pehkui:reach 1.3333333
scale set pehkui:step_height 0.7407407
scale set pehkui:jump_height 1.2
scale persist set pehkui:base true @s
scale persist set pehkui:height true @s
scale persist set pehkui:width true @s
scale persist set pehkui:motion true @s
scale persist set pehkui:attack true @s
scale persist set pehkui:reach true @s
scale persist set pehkui:step_height true @s
scale persist set pehkui:jump_height true @s