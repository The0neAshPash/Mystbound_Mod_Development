scale reset pehkui:base
scale reset pehkui:motion
scale reset pehkui:attack
scale reset pehkui:reach
scale reset pehkui:height
scale reset pehkui:width
scale reset pehkui:step_height
scale reset pehkui:jump_height
scale persist reset pehkui:height @s
scale persist reset pehkui:width @s
scale persist reset pehkui:base @s
scale persist reset pehkui:motion @s
scale persist reset pehkui:attack @s
scale persist reset pehkui:reach @s
scale persist reset pehkui:step_height @s
scale persist reset pehkui:jump_height @s
