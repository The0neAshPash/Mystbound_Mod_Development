scale set pehkui:height 1.5
scale set pehkui:width 2
scale set pehkui:motion 1.5
scale persist set pehkui:height true @s
scale persist set pehkui:width true @s
scale persist reset pehkui:motion @s
