scale set pehkui:base 1.5
scale set pehkui:width 1.8
scale persist set pehkui:base true @s
scale persist set pehkui:width true @s

