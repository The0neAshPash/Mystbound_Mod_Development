particle dust 0.46 1 0.84 0.6 ~ ~0.6 ~ 0.3 0.5 0.3 1 13
playsound mystbound-origins:jump_1 player @a ~ ~ ~ 0.5 1.0