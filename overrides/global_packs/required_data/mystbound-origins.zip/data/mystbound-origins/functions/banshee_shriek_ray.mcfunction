playsound minecraft:entity.ghast.hurt player @a ~ ~ ~ 0.68 0.9
playsound minecraft:entity.warden.sonic_boom player @a ~ ~ ~ 1.0 1.0
particle minecraft:sonic_boom ~ ~ ~ 0 0 0 0 3 force @a
effect give @e[type=!#mystbound-origins:bosses,predicate=!mystbound-origins:is_banshee,distance=..1,limit=1] minecraft:nausea 5 1
effect give @e[type=!#mystbound-origins:bosses,predicate=!mystbound-origins:is_banshee,distance=..1,limit=1] minecraft:weakness 5 1