scale set pehkui:base 0.166
scale set pehkui:hitbox_height 1.1
scale set pehkui:hitbox_width 1.7
scale set pehkui:drops 0.166
scale set pehkui:mining_speed 0.75
scale multiply pehkui:motion 6.024096

scale delay set 0 @s
scale persist set pehkui:height true @s
scale persist set pehkui:width true @s
scale persist set pehkui:hitbox_height true @s
scale persist set pehkui:hitbox_width true @s
scale persist set pehkui:drops true @s
scale persist set pehkui:mining_speed true @s