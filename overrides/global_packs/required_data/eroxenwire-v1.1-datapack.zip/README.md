# EWR-datapack
Eroxen's Wireless Redstone: adds Create Mod inspired Redstone Links
